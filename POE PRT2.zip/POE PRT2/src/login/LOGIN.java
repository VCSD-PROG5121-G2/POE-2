/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package login;

import java.awt.Component;
import javax.swing.JOptionPane;

/**
 *
 * @author 22200970
 */
public class LOGIN {
    static String password;
    static String username;
    static String username2;
    static String name;
    static String name2;
    static String password2;
    static String taskID;
    static String details;
    static String tDescript;
    static String tName;
    static int tNumb;
    static int duration;
    static int totHours;
    static int status;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //First a user needs to register
        JOptionPane.showMessageDialog(null, "Welcome user, please register before logging in.");

        name = JOptionPane.showInputDialog("Please enter your first name:");// must capture name data
        name2 = JOptionPane.showInputDialog("Please enter your last name:");// must capture name data
         System.out.println("Welcome to EasyKanBan");
        Object frame = null;
         //          datatype variasblename
            String UserOptions = JOptionPane.showInputDialog(frame, "Please pick the a option: \n\n 1:Create task:  \n\n 2:Done: \n\n 3: Busy Doing:");

      
    }
     public static void addtasks() {
        
        int noTasks; 
        noTasks = Integer.parseInt(JOptionPane.showInputDialog(null, "How many tasks do you wish to add?"));
        
        for (int i = 0; i < noTasks; i++) { // loop to keep going for amount of tasks needed to add
        
            tName = JOptionPane.showInputDialog(null, "Please enter the task name.");
            
            
            tNumb = Integer.parseInt(JOptionPane.showInputDialog(null, "Please enter the task number (Starting at 0)"));
     
            tDescript = JOptionPane.showInputDialog(null, "Please enter a description for your task, fewer than 50 words.");
           
            if (tDescript.length()<=50){
                
                JOptionPane.showMessageDialog(null, "Task succesfully captured.");
                
                details = JOptionPane.showInputDialog(null, "Please enter the developer details (Fisrt and last name of develepor assigned to the task. ");
                
                
                duration = Integer.parseInt(JOptionPane.showInputDialog(null, "Please enter the estimated duration of time (In hours) that the task should take"));
                
                JOptionPane.showMessageDialog(null, "Your Task ID is:" + tName.substring(0,2)+ ":" + Integer.toString(tNumb) + ":" + details.substring(details.length()-3) + "");
                 
                status();// call upon classes to execute in order
                results();
                hours();
                }
            else {
                JOptionPane.showMessageDialog(null, "“Please enter a task description of less than 50 characters");// rejects descriptions that doesn not follow the format
                
            }
            
        }
    }
      public static int status(){
          
            int status = Integer.parseInt(JOptionPane.showInputDialog(" Is your Task \n " + "1: To do \n" + "2: Done \n" + "3: Doing"));
            String statusMes = null;
            switch (status){
                case 1 :
                    statusMes = "To do"; // needed to change the integer chosen to the string of the status
                    
                case 2 :
                    statusMes = " Done";
                    
                case 3 :
                    statusMes = "Doing";
            }
     return status;
      }
       public static void hours(){
            
            totHours = totHours+ duration;
            JOptionPane.showMessageDialog(null, "Your total hours needed for your tasks is " + totHours +  "hours");

      


   
       }

    private static void results() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
